package util;
import java.io.*;
import java.util.*;

public class DBPropertyUtil {
    public static Properties getConnectionString(String fileName) throws IOException {
        FileInputStream fis = new FileInputStream(fileName);
        Properties prop = new Properties();
        prop.load(fis);
        return prop;
    }
}
