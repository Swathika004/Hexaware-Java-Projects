package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnUtil {
    public static Connection getConnection() {
        Connection conn = null;
        try {
            Properties prop = DBPropertyUtil.getConnectionString("src/db.properties");
            Class.forName(prop.getProperty("db.driver"));
            conn = DriverManager.getConnection(
                prop.getProperty("db.url"),
                prop.getProperty("db.username"),
                prop.getProperty("db.password")
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}

