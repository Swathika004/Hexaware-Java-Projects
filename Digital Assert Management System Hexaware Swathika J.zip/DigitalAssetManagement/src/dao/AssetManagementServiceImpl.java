package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.*;
import util.DBConnUtil;
import exception.AssetNotFoundException;

public class AssetManagementServiceImpl implements AssetManagementService {

    private Connection conn;

    public AssetManagementServiceImpl() {
        conn = DBConnUtil.getConnection();
    }

    @Override
    public boolean addAsset(Asset asset) {
        try {
            String sql = "INSERT INTO assets VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, asset.getAssetId());
            stmt.setString(2, asset.getName());
            stmt.setString(3, asset.getType());
            stmt.setString(4, asset.getSerialNumber());
            stmt.setDate(5, Date.valueOf(asset.getPurchaseDate()));
            stmt.setString(6, asset.getLocation());
            stmt.setString(7, asset.getStatus());
            stmt.setInt(8, asset.getOwnerId());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in addAsset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean updateAsset(Asset asset) {
        try {
            String sql = "UPDATE assets SET name=?, type=?, serial_number=?, purchase_date=?, location=?, status=?, owner_id=? WHERE asset_id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, asset.getName());
            stmt.setString(2, asset.getType());
            stmt.setString(3, asset.getSerialNumber());
            stmt.setDate(4, Date.valueOf(asset.getPurchaseDate()));
            stmt.setString(5, asset.getLocation());
            stmt.setString(6, asset.getStatus());
            stmt.setInt(7, asset.getOwnerId());
            stmt.setInt(8, asset.getAssetId());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in updateAsset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteAsset(int assetId) throws AssetNotFoundException {
        try {
            // Step 1: Check if the asset exists
            String checkSql = "SELECT * FROM assets WHERE asset_id=?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, assetId);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                // Step 2: Throw custom exception if not found
                throw new AssetNotFoundException("Asset ID " + assetId + " not found!");
            }

            // Step 3: Proceed to delete
            String sql = "DELETE FROM assets WHERE asset_id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, assetId);
            int rows = stmt.executeUpdate();

            return rows > 0;

        } catch (SQLException e) {
            System.out.println("SQL Error in deleteAsset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean allocateAsset(int assetId, int employeeId, String allocationDate) {
        try {
            String sql = "INSERT INTO asset_allocations (asset_id, employee_id, allocation_date) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, assetId);
            stmt.setInt(2, employeeId);
            stmt.setDate(3, Date.valueOf(allocationDate));
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in allocateAsset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deallocateAsset(int assetId, int employeeId, String returnDate) {
        try {
            String sql = "UPDATE asset_allocations SET return_date=? WHERE asset_id=? AND employee_id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDate(1, Date.valueOf(returnDate));
            stmt.setInt(2, assetId);
            stmt.setInt(3, employeeId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in deallocateAsset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost) {
        try {
            String sql = "INSERT INTO maintenance_records (asset_id, maintenance_date, description, cost) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, assetId);
            stmt.setDate(2, Date.valueOf(maintenanceDate));
            stmt.setString(3, description);
            stmt.setDouble(4, cost);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in performMaintenance: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate) {
        try {
            String sql = "INSERT INTO reservations (asset_id, employee_id, reservation_date, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, assetId);
            stmt.setInt(2, employeeId);
            stmt.setDate(3, Date.valueOf(reservationDate));
            stmt.setDate(4, Date.valueOf(startDate));
            stmt.setDate(5, Date.valueOf(endDate));
            stmt.setString(6, "pending");
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in reserveAsset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean withdrawReservation(int reservationId) {
        try {
            String sql = "UPDATE reservations SET status='cancelled' WHERE reservation_id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, reservationId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in withdrawReservation: " + e.getMessage());
            return false;
        }
    }
}
