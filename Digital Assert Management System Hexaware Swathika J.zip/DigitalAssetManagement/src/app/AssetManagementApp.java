package app;

import dao.AssetManagementService;
import dao.AssetManagementServiceImpl;
import entity.Asset;
import exception.AssetNotFoundException;


import java.util.Scanner;

public class AssetManagementApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        AssetManagementService service = new AssetManagementServiceImpl();
        int choice;

        do {
            System.out.println("\n=== Digital Asset Management Menu ===");
            System.out.println("1. Add Asset");
            System.out.println("2. Update Asset");
            System.out.println("3. Delete Asset");
            System.out.println("4. Allocate Asset");
            System.out.println("5. Deallocate Asset");
            System.out.println("6. Perform Maintenance");
            System.out.println("7. Reserve Asset");
            System.out.println("8. Withdraw Reservation");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.println("\nEnter Asset Details:");
                    System.out.print("Asset ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Type: ");
                    String type = sc.nextLine();
                    System.out.print("Serial Number: ");
                    String serial = sc.nextLine();
                    System.out.print("Purchase Date (yyyy-mm-dd): ");
                    String purchaseDate = sc.nextLine();
                    System.out.print("Location: ");
                    String location = sc.nextLine();
                    System.out.print("Status: ");
                    String status = sc.nextLine();
                    System.out.print("Owner ID: ");
                    int ownerId = sc.nextInt();

                    Asset newAsset = new Asset(id, name, type, serial, purchaseDate, location, status, ownerId);
                    if (service.addAsset(newAsset)) {
                        System.out.println("Asset added successfully!");
                    } else {
                        System.out.println("Failed to add asset.");
                    }
                    break;

                case 2:
                    System.out.println("\nUpdate Asset:");
                    System.out.print("Asset ID to update: ");
                    int upId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("New Name: ");
                    String upName = sc.nextLine();
                    System.out.print("New Type: ");
                    String upType = sc.nextLine();
                    System.out.print("New Serial Number: ");
                    String upSerial = sc.nextLine();
                    System.out.print("New Purchase Date (yyyy-mm-dd): ");
                    String upPurchase = sc.nextLine();
                    System.out.print("New Location: ");
                    String upLocation = sc.nextLine();
                    System.out.print("New Status: ");
                    String upStatus = sc.nextLine();
                    System.out.print("New Owner ID: ");
                    int upOwnerId = sc.nextInt();

                    Asset upAsset = new Asset(upId, upName, upType, upSerial, upPurchase, upLocation, upStatus, upOwnerId);
                    if (service.updateAsset(upAsset)) {
                        System.out.println("Asset updated successfully!");
                    } else {
                        System.out.println("Failed to update asset.");
                    }
                    break;

                case 3:
                    System.out.print("\nEnter Asset ID to delete: ");
                    int delId = sc.nextInt();
                    try {
                        if (service.deleteAsset(delId)) {
                            System.out.println("Asset deleted successfully.");
                        } else {
                            System.out.println("Failed to delete asset.");
                        }
                    } catch (AssetNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;


                case 4:
                    System.out.print("\nEnter Asset ID to allocate: ");
                    int allocAssetId = sc.nextInt();
                    System.out.print("Enter Employee ID: ");
                    int allocEmpId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Allocation Date (yyyy-mm-dd): ");
                    String allocDate = sc.nextLine();
                    if (service.allocateAsset(allocAssetId, allocEmpId, allocDate)) {
                        System.out.println("Asset allocated successfully.");
                    } else {
                        System.out.println("Failed to allocate asset.");
                    }
                    break;

                case 5:
                    System.out.print("\nEnter Asset ID to deallocate: ");
                    int deallocAssetId = sc.nextInt();
                    System.out.print("Enter Employee ID: ");
                    int deallocEmpId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Return Date (yyyy-mm-dd): ");
                    String returnDate = sc.nextLine();
                    if (service.deallocateAsset(deallocAssetId, deallocEmpId, returnDate)) {
                        System.out.println("Asset deallocated successfully.");
                    } else {
                        System.out.println("Failed to deallocate asset.");
                    }
                    break;

                case 6:
                    System.out.print("\nEnter Asset ID for maintenance: ");
                    int mAssetId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Maintenance Date (yyyy-mm-dd): ");
                    String mDate = sc.nextLine();
                    System.out.print("Enter Description: ");
                    String mDesc = sc.nextLine();
                    System.out.print("Enter Cost: ");
                    double mCost = sc.nextDouble();
                    if (service.performMaintenance(mAssetId, mDate, mDesc, mCost)) {
                        System.out.println("Maintenance recorded successfully.");
                    } else {
                        System.out.println("Failed to record maintenance.");
                    }
                    break;

                case 7:
                    System.out.print("\nEnter Asset ID to reserve: ");
                    int rAssetId = sc.nextInt();
                    System.out.print("Enter Employee ID: ");
                    int rEmpId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Reservation Date (yyyy-mm-dd): ");
                    String rDate = sc.nextLine();
                    System.out.print("Enter Start Date (yyyy-mm-dd): ");
                    String rStart = sc.nextLine();
                    System.out.print("Enter End Date (yyyy-mm-dd): ");
                    String rEnd = sc.nextLine();
                    if (service.reserveAsset(rAssetId, rEmpId, rDate, rStart, rEnd)) {
                        System.out.println("Asset reserved successfully.");
                    } else {
                        System.out.println("Failed to reserve asset.");
                    }
                    break;

                case 8:
                    System.out.print("\nEnter Reservation ID to cancel: ");
                    int cancelId = sc.nextInt();
                    if (service.withdrawReservation(cancelId)) {
                        System.out.println("Reservation cancelled.");
                    } else {
                        System.out.println("Failed to cancel reservation.");
                    }
                    break;

                case 9:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        } while (choice != 9);

        sc.close();
    }
}
