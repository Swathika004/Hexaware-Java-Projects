package exception;

public class AssetNotMaintainException extends Exception {
    public AssetNotMaintainException(String message) {
        super(message);
    }
}
