package entity;

import exception.OverDraftLimitExceededException;

public class CurrentAccount extends Account {
    private double overdraftLimit;

    public CurrentAccount() {
        super();
        this.overdraftLimit = 1000.0;
        setAccountType("CURRENT");
    }

    public CurrentAccount(Customer customer, double balance) {
        super(customer, "CURRENT", balance);
        this.overdraftLimit = 1000.0;
    }

    public double getOverdraftLimit() { return overdraftLimit; }
    public void setOverdraftLimit(double overdraftLimit) { this.overdraftLimit = overdraftLimit; }

    @Override
    public void deposit(float amount) {
        if (amount > 0) {
            setBalance(getBalance() + amount);
        }
    }

    @Override
    public void deposit(int amount) {
        deposit((float) amount);
    }

    @Override
    public void deposit(double amount) {
        deposit((float) amount);
    }

    @Override
    public void withdraw(float amount) throws OverDraftLimitExceededException {
        if (amount > 0 && getBalance() - amount >= -overdraftLimit) {
            setBalance(getBalance() - amount);
        } else {
            throw new OverDraftLimitExceededException("Overdraft limit exceeded for Current Account");
        }
    }

    @Override
    public void withdraw(int amount) throws OverDraftLimitExceededException {
        withdraw((float) amount);
    }

    @Override
    public void withdraw(double amount) throws OverDraftLimitExceededException {
        withdraw((float) amount);
    }

    @Override
    public double calculateInterest() {
        return 0.0; // No interest for Current Account
    }
}
