package entity;

import exception.InsufficientFundException;

public class SavingsAccount extends Account {
    private double interestRate;
    private static final double MINIMUM_BALANCE = 500.0;

    public SavingsAccount() {
        super();
        this.interestRate = 4.5;
        setAccountType("SAVINGS");
    }

    public SavingsAccount(Customer customer, double balance) {
        super(customer, "SAVINGS", balance >= MINIMUM_BALANCE ? balance : MINIMUM_BALANCE);
        this.interestRate = 4.5;
    }

    public double getInterestRate() { return interestRate; }
    public void setInterestRate(double interestRate) { this.interestRate = interestRate; }

    @Override
    public void deposit(float amount) {
        if (amount > 0) {
            setBalance(getBalance() + amount);
        }
    }

    @Override
    public void deposit(int amount) {
        deposit((float) amount);
    }

    @Override
    public void deposit(double amount) {
        deposit((float) amount);
    }

    @Override
    public void withdraw(float amount) throws InsufficientFundException {
        if (amount > 0 && getBalance() - amount >= MINIMUM_BALANCE) {
            setBalance(getBalance() - amount);
        } else {
            throw new InsufficientFundException("Insufficient funds or minimum balance violation for Savings Account");
        }
    }

    @Override
    public void withdraw(int amount) throws InsufficientFundException {
        withdraw((float) amount);
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundException {
        withdraw((float) amount);
    }

    @Override
    public double calculateInterest() {
        return getBalance() * (interestRate / 100);
    }
}