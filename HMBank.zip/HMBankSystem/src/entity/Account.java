package entity;

public abstract class Account {
    private long accountNumber;
    private String accountType;
    private double balance;
    private Customer customer;
    protected static long lastAccNo = 1000;

    // Default constructor
    public Account() {
        this.accountNumber = ++lastAccNo;
    }

    // Parameterized constructor
    public Account(Customer customer, String accountType, double balance) {
        this.accountNumber = ++lastAccNo;
        this.customer = customer;
        this.accountType = accountType;
        this.balance = balance;
    }

    // Getters and setters
    public long getAccountNumber() { return accountNumber; }
    public void setAccountNumber(long accountNumber) { this.accountNumber = accountNumber; }
    public String getAccountType() { return accountType; }
    public void setAccountType(String accountType) { this.accountType = accountType; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { this.customer = customer; }

    // Abstract methods
    public abstract void deposit(float amount);
    public abstract void deposit(int amount);
    public abstract void deposit(double amount);
    public abstract void withdraw(float amount) throws Exception;
    public abstract void withdraw(int amount) throws Exception;
    public abstract void withdraw(double amount) throws Exception;
    public abstract double calculateInterest();

    @Override
    public String toString() {
        return "Account [accountNumber=" + accountNumber + ", accountType=" + accountType +
               ", balance=" + balance + ", customer=" + customer + "]";
    }
}