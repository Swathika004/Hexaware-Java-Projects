package entity;

import exception.InsufficientFundException;

public class ZeroBalanceAccount extends Account {

    public ZeroBalanceAccount() {
        super();
        setAccountType("ZERO_BALANCE");
        setBalance(0.0);
    }

    public ZeroBalanceAccount(Customer customer) {
        super(customer, "ZERO_BALANCE", 0.0);
    }

    @Override
    public void deposit(float amount) {
        if (amount > 0) {
            setBalance(getBalance() + amount);
        }
    }

    @Override
    public void deposit(int amount) {
        deposit((float) amount);
    }

    @Override
    public void deposit(double amount) {
        deposit((float) amount);
    }

    @Override
    public void withdraw(float amount) throws InsufficientFundException {
        if (amount > 0 && getBalance() >= amount) {
            setBalance(getBalance() - amount);
        } else {
            throw new InsufficientFundException("Insufficient funds for Zero Balance Account");
        }
    }

    @Override
    public void withdraw(int amount) throws InsufficientFundException {
        withdraw((float) amount);
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundException {
        withdraw((float) amount);
    }

    @Override
    public double calculateInterest() {
        return 0.0; // No interest for Zero Balance Account
    }
}