package main;

import dao.*;
import entity.*;
import exception.*;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class BankApp {
    private static IBankServiceProvider bankService;

    public static void main(String[] args) {
        bankService = new BankServiceProviderImpl(new BankRepositoryImpl());
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            try {
                System.out.println("\n=== HMBank System ===");
                System.out.println("1. Create Account");
                System.out.println("2. Deposit");
                System.out.println("3. Withdraw");
                System.out.println("4. Get Balance");
                System.out.println("5. Transfer");
                System.out.println("6. Get Account Details");
                System.out.println("7. List Accounts");
                System.out.println("8. Get Transactions");
                System.out.println("9. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        createAccount(scanner);
                        break;
                    case 2:
                        deposit(scanner);
                        break;
                    case 3:
                        withdraw(scanner);
                        break;
                    case 4:
                        getBalance(scanner);
                        break;
                    case 5:
                        transfer(scanner);
                        break;
                    case 6:
                        getAccountDetails(scanner);
                        break;
                    case 7:
                        listAccounts();
                        break;
                    case 8:
                        getTransactions(scanner);
                        break;
                    case 9:
                        exit = true;
                        System.out.println("Thank you for using HMBank System!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InvalidAccountException | InsufficientFundException | OverDraftLimitExceededException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (NullPointerException e) {
                System.out.println("Error: Null pointer encountered. Please check input data.");
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
        scanner.close();
    }

    private static void createAccount(Scanner scanner) {
        System.out.println("\n=== Create Account ===");
        System.out.println("1. Savings Account");
        System.out.println("2. Current Account");
        System.out.println("3. Zero Balance Account");
        System.out.print("Select account type: ");
        int accTypeChoice = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter DOB (YYYY-MM-DD): ");
        String dobStr = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Phone Number: ");
        String phone = scanner.nextLine();
        System.out.print("Enter Address: ");
        String address = scanner.nextLine();
        System.out.print("Enter Initial Balance: ");
        float balance = scanner.nextFloat();

        Customer customer = new Customer(customerId, firstName, lastName, Date.valueOf(dobStr), email, phone, address);
        String accType;
        switch (accTypeChoice) {
            case 1:
                accType = "SAVINGS";
                break;
            case 2:
                accType = "CURRENT";
                break;
            case 3:
                accType = "ZERO_BALANCE";
                break;
            default:
                System.out.println("Invalid account type.");
                return;
        }

        bankService.createAccount(customer, 0, accType, balance);
        System.out.println("Account created successfully!");
    }

    private static void deposit(Scanner scanner) {
        System.out.print("Enter Account Number: ");
        long accNo = scanner.nextLong();
        System.out.print("Enter Deposit Amount: ");
        float amount = scanner.nextFloat();
        bankService.deposit(accNo, amount);
        System.out.println("Deposit successful. New balance: " + bankService.getAccountBalance(accNo));
    }

    private static void withdraw(Scanner scanner) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException {
        System.out.print("Enter Account Number: ");
        long accNo = scanner.nextLong();
        System.out.print("Enter Withdrawal Amount: ");
        float amount = scanner.nextFloat();
        bankService.withdraw(accNo, amount);
        System.out.println("Withdrawal successful. New balance: " + bankService.getAccountBalance(accNo));
    }

    private static void getBalance(Scanner scanner) throws InvalidAccountException {
        System.out.print("Enter Account Number: ");
        long accNo = scanner.nextLong();
        System.out.println("Current Balance: " + bankService.getAccountBalance(accNo));
    }

    private static void transfer(Scanner scanner) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException {
        System.out.print("Enter From Account Number: ");
        long fromAccNo = scanner.nextLong();
        System.out.print("Enter To Account Number: ");
        long toAccNo = scanner.nextLong();
        System.out.print("Enter Transfer Amount: ");
        float amount = scanner.nextFloat();
        bankService.transfer(fromAccNo, toAccNo, amount);
        System.out.println("Transfer successful.");
    }

    private static void getAccountDetails(Scanner scanner) throws InvalidAccountException {
        System.out.print("Enter Account Number: ");
        long accNo = scanner.nextLong();
        Account account = bankService.getAccountDetails(accNo);
        System.out.println(account);
    }

    private static void listAccounts() {
        List<Account> accounts = bankService.listAccounts();
        if (accounts.isEmpty()) {
            System.out.println("No accounts found.");
        } else {
            for (Account acc : accounts) {
                System.out.println(acc);
            }
        }
    }

    private static void getTransactions(Scanner scanner) throws InvalidAccountException {
        System.out.print("Enter Account Number: ");
        long accNo = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter From Date (YYYY-MM-DD): ");
        String fromDateStr = scanner.nextLine();
        System.out.print("Enter To Date (YYYY-MM-DD): ");
        String toDateStr = scanner.nextLine();
        List<Transaction> transactions = bankService.getTransactions(accNo, Date.valueOf(fromDateStr), Date.valueOf(toDateStr));
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            for (Transaction trans : transactions) {
                System.out.println(trans);
            }
        }
    }
}
