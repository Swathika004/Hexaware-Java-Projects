package dao;

import entity.Account;
import entity.Customer;
import exception.InvalidAccountException;

import java.util.List;

public interface IBankServiceProvider extends ICustomerServiceProvider {
    void createAccount(Customer customer, long accNo, String accType, float balance);
    List<Account> listAccounts();
    double calculateInterest(long accountNumber) throws InvalidAccountException;
}
