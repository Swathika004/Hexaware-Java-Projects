package dao;

import entity.Account;
import entity.Customer;
import exception.InvalidAccountException;

import java.util.ArrayList;
import java.util.List;

public class BankServiceProviderImpl extends CustomerServiceProviderImpl implements IBankServiceProvider {
    private List<Account> accountList;
    private List<entity.Transaction> transactionList;
    private String branchName;
    private String branchAddress;
    private IBankRepository repository;

    public BankServiceProviderImpl(IBankRepository repository) {
        super(repository);
        this.repository = repository;
        this.accountList = new ArrayList<>();
        this.transactionList = new ArrayList<>();
        this.branchName = "Main Branch";
        this.branchAddress = "123 Bank Street, City A";
    }

    @Override
    public void createAccount(Customer customer, long accNo, String accType, float balance) {
        repository.createAccount(customer, accNo, accType, balance);
    }

    @Override
    public List<Account> listAccounts() {
        return repository.listAccounts();
    }

    @Override
    public double calculateInterest(long accountNumber) throws InvalidAccountException {
        return repository.calculateInterest(accountNumber);
    }
}