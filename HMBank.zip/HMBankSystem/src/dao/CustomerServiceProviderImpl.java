package dao;

import entity.Account;
import entity.Transaction;
import exception.*;

import java.sql.Date;
import java.util.List;

public class CustomerServiceProviderImpl implements ICustomerServiceProvider {
    private IBankRepository repository;

    public CustomerServiceProviderImpl(IBankRepository repository) {
        this.repository = repository;
    }

    @Override
    public double getAccountBalance(long accountNumber) throws InvalidAccountException {
        return repository.getAccountBalance(accountNumber);
    }

    @Override
    public void deposit(long accountNumber, float amount) throws InvalidAccountException {
        repository.deposit(accountNumber, amount);
    }

    @Override
    public void withdraw(long accountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException {
        repository.withdraw(accountNumber, amount);
    }

    @Override
    public void transfer(long fromAccountNumber, long toAccountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException {
        repository.transfer(fromAccountNumber, toAccountNumber, amount);
    }

    @Override
    public Account getAccountDetails(long accountNumber) throws InvalidAccountException {
        return repository.getAccountDetails(accountNumber);
    }

    @Override
    public List<Transaction> getTransactions(long accountNumber, Date fromDate, Date toDate) throws InvalidAccountException {
        return repository.getTransactions(accountNumber, fromDate, toDate);
    }
}