package dao;

import entity.Account;
import entity.Customer;
import entity.Transaction;
import exception.*;

import java.sql.Date;
import java.util.List;

public interface IBankRepository {
    void createAccount(Customer customer, long accNo, String accType, float balance);
    List<Account> listAccounts();
    double calculateInterest(long accountNumber) throws InvalidAccountException;
    double getAccountBalance(long accountNumber) throws InvalidAccountException;
    void deposit(long accountNumber, float amount) throws InvalidAccountException;
    void withdraw(long accountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException;
    void transfer(long fromAccountNumber, long toAccountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException;
    Account getAccountDetails(long accountNumber) throws InvalidAccountException;
    List<Transaction> getTransactions(long accountNumber, Date fromDate, Date toDate) throws InvalidAccountException;
}