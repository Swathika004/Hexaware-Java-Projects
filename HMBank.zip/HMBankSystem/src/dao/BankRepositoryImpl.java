package dao;

import entity.*;
import exception.*;
import util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BankRepositoryImpl implements IBankRepository {

    @Override
    public void createAccount(Customer customer, long accNo, String accType, float balance) {
        String sql = "INSERT INTO Accounts (customer_id, account_type, balance) VALUES (?, ?, ?)";
        try (Connection conn = DBConnUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, customer.getCustomerId());
            stmt.setString(2, accType.toUpperCase());
            stmt.setDouble(3, balance);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error creating account: " + e.getMessage());
        }
    }

    @Override
    public List<Account> listAccounts() {
        List<Account> accounts = new ArrayList<>();
        String sql = "SELECT a.account_id, a.customer_id, a.account_type, a.balance, " +
                     "c.first_name, c.last_name, c.DOB, c.email, c.phone_number, c.address " +
                     "FROM Accounts a JOIN Customers c ON a.customer_id = c.customer_id";
        try (Connection conn = DBConnUtil.getDBConn();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Customer customer = new Customer(
                    rs.getInt("customer_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("DOB"),
                    rs.getString("email"),
                    rs.getString("phone_number"),
                    rs.getString("address")
                );
                Account account;
                String accType = rs.getString("account_type");
                switch (accType) {
                    case "SAVINGS":
                        account = new SavingsAccount(customer, rs.getDouble("balance"));
                        break;
                    case "CURRENT":
                        account = new CurrentAccount(customer, rs.getDouble("balance"));
                        break;
                    case "ZERO_BALANCE":
                        account = new ZeroBalanceAccount(customer);
                        break;
                    default:
                        throw new InvalidAccountException("Unknown account type: " + accType);
                }
                account.setAccountNumber(rs.getLong("account_id"));
                accounts.add(account);
            }
        } catch (SQLException | InvalidAccountException e) {
            throw new RuntimeException("Error listing accounts: " + e.getMessage());
        }
        return accounts;
    }

    @Override
    public double calculateInterest(long accountNumber) throws InvalidAccountException {
        Account account = getAccountDetails(accountNumber);
        return account.calculateInterest();
    }

    @Override
    public double getAccountBalance(long accountNumber) throws InvalidAccountException {
        String sql = "SELECT balance FROM Accounts WHERE account_id = ?";
        try (Connection conn = DBConnUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, accountNumber);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("balance");
            } else {
                throw new InvalidAccountException("Account number " + accountNumber + " not found");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving balance: " + e.getMessage());
        }
    }

    @Override
    public void deposit(long accountNumber, float amount) throws InvalidAccountException {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        String sql = "UPDATE Accounts SET balance = balance + ? WHERE account_id = ?";
        String transSql = "INSERT INTO Transactions (account_id, transaction_type, amount) VALUES (?, 'DEPOSIT', ?)";
        Connection conn = null;
        try {
            conn = DBConnUtil.getDBConn();
            conn.setAutoCommit(false);

            // Update balance
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDouble(1, amount);
                stmt.setLong(2, accountNumber);
                int rows = stmt.executeUpdate();
                if (rows == 0) {
                    throw new InvalidAccountException("Account number " + accountNumber + " not found");
                }
            }

            // Record transaction
            try (PreparedStatement transStmt = conn.prepareStatement(transSql)) {
                transStmt.setLong(1, accountNumber);
                transStmt.setDouble(2, amount);
                transStmt.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            throw new RuntimeException("Error during deposit: " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void withdraw(long accountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        String sql = "SELECT account_type, balance FROM Accounts WHERE account_id = ?";
        String updateSql = "UPDATE Accounts SET balance = balance - ? WHERE account_id = ?";
        String transSql = "INSERT INTO Transactions (account_id, transaction_type, amount) VALUES (?, 'WITHDRAWAL', ?)";
        Connection conn = null;
        try {
            conn = DBConnUtil.getDBConn();
            conn.setAutoCommit(false);

            // Check balance and account type
            double balance;
            String accType;
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setLong(1, accountNumber);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    balance = rs.getDouble("balance");
                    accType = rs.getString("account_type");
                } else {
                    throw new InvalidAccountException("Account number " + accountNumber + " not found");
                }
            }

            // Validate withdrawal
            if (accType.equals("SAVINGS") && balance - amount < SavingsAccount.MINIMUM_BALANCE) {
                throw new InsufficientFundException("Withdrawal violates minimum balance for Savings Account");
            } else if (accType.equals("CURRENT") && balance - amount < -1000.0) {
                throw new OverDraftLimitExceededException("Overdraft limit exceeded for Current Account");
            } else if (accType.equals("ZERO_BALANCE") && balance < amount) {
                throw new InsufficientFundException("Insufficient funds for Zero Balance Account");
            }

            // Update balance
            try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                stmt.setDouble(1, amount);
                stmt.setLong(2, accountNumber);
                stmt.executeUpdate();
            }

            // Record transaction
            try (PreparedStatement transStmt = conn.prepareStatement(transSql)) {
                transStmt.setLong(1, accountNumber);
                transStmt.setDouble(2, amount);
                transStmt.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            throw new RuntimeException("Error during withdrawal: " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void transfer(long fromAccountNumber, long toAccountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException {
        if (amount <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive");
        }
        Connection conn = null;
        try {
            conn = DBConnUtil.getDBConn();
            conn.setAutoCommit(false);

            // Withdraw from source account
            withdraw(fromAccountNumber, amount);

            // Deposit to destination account
            deposit(toAccountNumber, amount);

            // Record transfer transaction
            String transSql = "INSERT INTO Transactions (account_id, transaction_type, amount) VALUES (?, 'TRANSFER', ?)";
            try (PreparedStatement transStmt = conn.prepareStatement(transSql)) {
                transStmt.setLong(1, fromAccountNumber);
                transStmt.setDouble(2, amount);
                transStmt.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            throw new RuntimeException("Error during transfer: " + e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public Account getAccountDetails(long accountNumber) throws InvalidAccountException {
        String sql = "SELECT a.account_id, a.customer_id, a.account_type, a.balance, " +
                     "c.first_name, c.last_name, c.DOB, c.email, c.phone_number, c.address " +
                     "FROM Accounts a JOIN Customers c ON a.customer_id = c.customer_id " +
                     "WHERE a.account_id = ?";
        try (Connection conn = DBConnUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, accountNumber);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Customer customer = new Customer(
                    rs.getInt("customer_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("DOB"),
                    rs.getString("email"),
                    rs.getString("phone_number"),
                    rs.getString("address")
                );
                Account account;
                String accType = rs.getString("account_type");
                switch (accType) {
                    case "SAVINGS":
                        account = new SavingsAccount(customer, rs.getDouble("balance"));
                        break;
                    case "CURRENT":
                        account = new CurrentAccount(customer, rs.getDouble("balance"));
                        break;
                    case "ZERO_BALANCE":
                        account = new ZeroBalanceAccount(customer);
                        break;
                    default:
                        throw new InvalidAccountException("Unknown account type: " + accType);
                }
                account.setAccountNumber(rs.getLong("account_id"));
                return account;
            } else {
                throw new InvalidAccountException("Account number " + accountNumber + " not found");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving account details: " + e.getMessage());
        }
    }

    @Override
    public List<Transaction> getTransactions(long accountNumber, Date fromDate, Date toDate) throws InvalidAccountException {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT transaction_id, account_id, transaction_type, amount, transaction_date " +
                     "FROM Transactions WHERE account_id = ? AND transaction_date BETWEEN ? AND ?";
        try (Connection conn = DBConnUtil.getDBConn();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, accountNumber);
            stmt.setDate(2, fromDate);
            stmt.setDate(3, toDate);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                transactions.add(new Transaction(
                    rs.getInt("transaction_id"),
                    rs.getLong("account_id"),
                    rs.getString("transaction_type"),
                    rs.getDouble("amount"),
                    rs.getTimestamp("transaction_date")
                ));
            }
            if (transactions.isEmpty()) {
                throw new InvalidAccountException("No transactions found for account number " + accountNumber);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving transactions: " + e.getMessage());
        }
        return transactions;
    }
}