package dao;

import entity.Account;
import entity.Transaction;
import exception.*;

import java.sql.Date;
import java.util.List;

public interface ICustomerServiceProvider {
    double getAccountBalance(long accountNumber) throws InvalidAccountException;
    void deposit(long accountNumber, float amount) throws InvalidAccountException;
    void withdraw(long accountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException;
    void transfer(long fromAccountNumber, long toAccountNumber, float amount) throws InvalidAccountException, InsufficientFundException, OverDraftLimitExceededException;
    Account getAccountDetails(long accountNumber) throws InvalidAccountException;
    List<Transaction> getTransactions(long accountNumber, Date fromDate, Date toDate) throws InvalidAccountException;
}
