package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {
    public static Connection getDBConn() {
        String connectionString = DBPropertyUtil.getConnectionString("db.properties");
        try {
            return DriverManager.getConnection(connectionString);
        } catch (SQLException e) {
            throw new RuntimeException("Error establishing database connection: " + e.getMessage());
        }
    }
}